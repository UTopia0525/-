extends "res://prototypes/f_style_trial/dowon_actor.gd"
## Shares original movement and collision; changes only displayed walk art.
var use_revision: bool = true
var review_cycle_distance: float = 1.9
var manual_frame: int = -1
var direction_frames: Array = []
var displayed_frame: int = 0
var corrected_idles: Dictionary = {}
var idle_anchors: Dictionary = {3: Vector2(438, 864), 4: Vector2(443.5, 864), 5: Vector2(466, 834), 6: Vector2(480, 834)}
var idle_scales: Dictionary = {3: 96.0 / 864.0, 4: 96.0 / 864.0, 5: 96.0 / 810.0, 6: 96.0 / 810.0}

func setup(art: Dictionary) -> void:
	for direction in art.directions:
		var sheet: Texture2D = load("res://prototypes/f_style_trial/walk8/%s.png" % direction)
		var frames: Array[AtlasTexture] = []
		for index in range(8):
			var column: int = index % 4
			var row: int = index / 4
			var left: int = roundi(column * sheet.get_width() / 4.0)
			var right: int = roundi((column + 1) * sheet.get_width() / 4.0)
			var top: int = roundi(row * sheet.get_height() / 2.0)
			var bottom: int = roundi((row + 1) * sheet.get_height() / 2.0)
			var frame := AtlasTexture.new()
			frame.atlas = sheet
			frame.region = Rect2(left, top, right - left, bottom - top)
			frames.append(frame)
		direction_frames.append(frames)
	var idle_sheet: Texture2D = load("res://prototypes/f_style_trial/walk8/idle-left-hip.png")
	for direction in [5, 6]:
		var idle := AtlasTexture.new()
		idle.atlas = idle_sheet
		idle.region = Rect2(887 if direction == 5 else 0, 0, 887, 887)
		corrected_idles[direction] = idle
	var back_sheet: Texture2D = load("res://prototypes/f_style_trial/walk8/idle-back-left-hip.png")
	for direction in [3, 4]:
		var idle := AtlasTexture.new()
		idle.atlas = back_sheet
		idle.region = Rect2(887 if direction == 4 else 0, 0, 887, 887)
		corrected_idles[direction] = idle
	super.setup(art)

func _pose() -> void:
	if not is_instance_valid(sprite): return
	if not moving and manual_frame < 0:
		if use_revision and corrected_idles.has(direction_index):
			displayed_frame = 0
			sprite.texture = corrected_idles[direction_index]
			sprite.scale = Vector2.ONE * idle_scales[direction_index]
			sprite.position = -idle_anchors[direction_index] * sprite.scale
			return
		displayed_frame = walk_frame
		super._pose()
		return
	var phase: float = fposmod(distance_walked / review_cycle_distance, 1.0)
	if manual_frame >= 0: phase = manual_frame / 8.0
	if not use_revision:
		walk_frame = mini(3, floori(phase * 4.0))
		displayed_frame = walk_frame
		super._pose()
		return
	displayed_frame = mini(7, floori(phase * 8.0))
	sprite.texture = direction_frames[direction_index][displayed_frame]
	sprite.scale = Vector2.ONE * (96.0 / 443.5)
	sprite.position = -Vector2(221.75, 430.0) * sprite.scale

func toggle_revision() -> void:
	use_revision = not use_revision
	_pose()

func toggle_cycle() -> void:
	review_cycle_distance = 3.84 if is_equal_approx(review_cycle_distance, 1.9) else 1.9
	_pose()

func step_pose() -> void:
	manual_frame = (manual_frame + 1) % 8
	_pose()

func turn_review(step: int) -> void:
	direction_index = posmod(direction_index + step, 8)
	if manual_frame < 0: manual_frame = 0
	_pose()

func resume_pose() -> void:
	manual_frame = -1
	_pose()
