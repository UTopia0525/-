extends "res://prototypes/f_style_trial/trial.gd"
const Walk8Actor = preload("res://prototypes/f_style_trial/walk8/walk8_actor.gd")
var review_paused: bool = false
const DIRECTION_NAMES: Array[String] = ["아래", "왼쪽 아래", "왼쪽", "왼쪽 위", "위", "오른쪽 위", "오른쪽", "오른쪽 아래"]

func _ready() -> void:
	super._ready()
	var previous_actor = actor
	var start: Vector2 = previous_actor.logical
	depth_root.remove_child(previous_actor)
	previous_actor.queue_free()
	actor = Walk8Actor.new()
	actor.setup(art)
	depth_root.add_child(actor)
	actor.set_logical(start)
	follow = true
	status.add_theme_font_size_override("font_size", 15)
	title.add_theme_font_size_override("font_size", 16)
	title.text = "도원 · 8방향 보행 비교\nWASD/방향키 · V 기존/수정 · T 주기 비교\nP 정지 · N 한 프레임 · Q/E 검토 방향 · R 초기화 · C 시점"
	title.get_parent().size = Vector2(maxf(400, get_viewport_rect().size.x - 384), 98)
	detail.size.y = 270
	status.position.y = 365
	status.get_parent().size.y = maxf(600, get_viewport_rect().size.y - 48)
	for label in find_children("*", "Label", true, false):
		if "실내·심리스·본게임" in label.text:
			label.text = "8방향×8프레임 · 아래 방향은 승인 원본\n본게임·기존 시험·저장 미변경 / 새7방향 사용자 검토용"

func _process(_delta: float) -> void:
	if actor == null: return
	_sort_depth()
	if follow: camera.position = actor.position + Vector2(180, -170)
	detail.texture = actor.sprite.texture
	var count: int = 8 if actor.use_revision and (actor.moving or actor.manual_frame >= 0) else 4
	if actor.use_revision and not actor.moving and actor.manual_frame < 0 and actor.corrected_idles.has(actor.direction_index): count = 1
	var seconds: float = actor.review_cycle_distance / actor.speed
	status.text = "%s · %s\n%s · 표시 프레임 %d/%d\n속도4.8 · 발 반경0.15\n카메라85%% · 캔버스96\n한 순환 %.2f칸 / %.3f초\nT: 기존1.9 / 검토3.84칸\n이동 속도는 유지\nP 정지 · N 한 프레임\nQ/E 정지하고 방향 비교\nV 같은 위치에서 그림 비교\nR 위치 초기화\n검은 인물의 왼쪽 허리\n새7방향은 검토 대기" % [DIRECTION_NAMES[actor.direction_index], "수정 8프레임" if actor.use_revision else "기존 4프레임", "검토 정지" if review_paused else ("보행" if actor.moving else "대기"), actor.displayed_frame + 1, count, actor.review_cycle_distance, seconds]

func set_review_paused(value: bool) -> void:
	review_paused = value
	actor.set_physics_process(not value)
	if not value: actor.resume_pose()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo: return
	match event.physical_keycode:
		KEY_V: actor.toggle_revision()
		KEY_T: actor.toggle_cycle()
		KEY_P: set_review_paused(not review_paused)
		KEY_N:
			set_review_paused(true)
			actor.step_pose()
		KEY_Q, KEY_E:
			set_review_paused(true)
			actor.turn_review(-1 if event.physical_keycode == KEY_Q else 1)
		KEY_R:
			set_review_paused(false)
			actor.distance_walked = 0.0
			super._unhandled_key_input(event)
		_: super._unhandled_key_input(event)
