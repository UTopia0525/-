extends "res://prototypes/f_style_trial/trial.gd"
const Walk8Actor = preload("res://prototypes/f_style_trial/walk8_volume_v3/standard_actor.gd")
var review_paused: bool = false
var reference_detail: TextureRect
const DIRECTION_NAMES: Array[String] = ["아래", "왼쪽 아래", "왼쪽", "왼쪽 위", "위", "오른쪽 위", "오른쪽", "오른쪽 아래"]

func _ready() -> void:
	super._ready()
	var previous_actor = actor
	var start: Vector2 = previous_actor.logical
	depth_root.remove_child(previous_actor)
	previous_actor.queue_free()
	actor = Walk8Actor.new()
	actor.setup(art)
	depth_root.add_child(actor)
	actor.set_logical(start)
	follow = true
	status.add_theme_font_size_override("font_size", 15)
	title.add_theme_font_size_override("font_size", 16)
	title.text = "도원 · 정지 기준 체적 보정 v3\nWASD/방향키 · V 기존/수정 · T 주기 비교\nP 정지 · N 한 프레임 · Q/E 방향 · O 기준 겹침 · I 정지 비교 · R 초기화"
	title.get_parent().size = Vector2(maxf(400, get_viewport_rect().size.x - 384), 98)
	detail.size.y = 270
	status.position.y = 365
	reference_detail = TextureRect.new()
	reference_detail.position = detail.position
	reference_detail.size = detail.size
	reference_detail.expand_mode = detail.expand_mode
	reference_detail.stretch_mode = detail.stretch_mode
	reference_detail.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	reference_detail.modulate = Color(0.2, 0.8, 1.0, 0.32)
	reference_detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	reference_detail.visible = false
	detail.get_parent().add_child(reference_detail)
	status.get_parent().size.y = maxf(600, get_viewport_rect().size.y - 48)
	for label in find_children("*", "Label", true, false):
		if "실내·심리스·본게임" in label.text:
			label.text = "정지 기준으로 보행64프레임 재제작 · 공통 크기·기준점\n본게임·기존 시험·저장 미변경 / 비율·보행 사용자 검토용"

func _process(_delta: float) -> void:
	if actor == null: return
	_sort_depth()
	if follow: camera.position = actor.position + Vector2(180, -170)
	detail.texture = actor.sprite.texture
	reference_detail.texture = actor.idle_textures[actor.direction_index]
	reference_detail.visible = actor.show_reference and actor.use_revision
	var count: int = 8 if actor.use_revision and not actor.force_idle and (actor.moving or actor.manual_frame >= 0) else 4
	if actor.use_revision and (actor.force_idle or (not actor.moving and actor.manual_frame < 0)): count = 1
	var seconds: float = actor.review_cycle_distance / actor.speed
	status.text = "%s · %s\n%s · 표시 프레임 %d/%d\n속도4.8 · 발 반경0.15\n카메라85%% · 공통 표시96\n한 순환 %.2f칸 / %.3f초\nT: 기존1.9 / 검토3.84칸\n이동 속도는 유지\nP 정지 · N 한 프레임\nQ/E 정지하고 방향 비교\nO 정지 기준 겹쳐 보기\nI 정지/보행 자세 비교\nV 기존 원본 · R 초기화\n정지↔보행 크기·체적감 검토" % [DIRECTION_NAMES[actor.direction_index], "수정 8프레임" if actor.use_revision else "기존 4프레임", "검토 정지" if review_paused else ("보행" if actor.moving else "대기"), actor.displayed_frame + 1, count, actor.review_cycle_distance, seconds]

func set_review_paused(value: bool) -> void:
	review_paused = value
	actor.set_physics_process(not value)
	if not value: actor.resume_pose()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo: return
	match event.physical_keycode:
		KEY_V: actor.toggle_revision()
		KEY_T: actor.toggle_cycle()
		KEY_P: set_review_paused(not review_paused)
		KEY_O:
			actor.show_reference = not actor.show_reference
			actor._pose()
		KEY_I:
			set_review_paused(true)
			actor.force_idle = not actor.force_idle
			actor._pose()
		KEY_N:
			set_review_paused(true)
			actor.step_pose()
		KEY_Q, KEY_E:
			set_review_paused(true)
			actor.turn_review(-1 if event.physical_keycode == KEY_Q else 1)
		KEY_R:
			set_review_paused(false)
			actor.distance_walked = 0.0
			super._unhandled_key_input(event)
		_: super._unhandled_key_input(event)
