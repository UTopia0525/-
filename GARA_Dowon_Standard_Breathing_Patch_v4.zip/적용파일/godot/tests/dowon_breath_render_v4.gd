extends SceneTree
const BASE = "res://prototypes/f_style_trial/dowon_standard_v4/"
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	root.size = Vector2i(384, 512)
	RenderingServer.set_default_clear_color(Color("eee9df"))
	var sprite = Sprite2D.new()
	sprite.centered = false
	var material = ShaderMaterial.new()
	material.shader = load(BASE + "breathing.gdshader")
	sprite.material = material
	root.add_child(sprite)
	var failed: int = 0
	for direction in ["S", "SW", "W", "NW", "N", "NE", "E", "SE"]:
		sprite.texture = load(BASE + "idle-%s.png" % direction)
		material.set_shader_parameter("inhale_px", 0.0)
		await process_frame
		await RenderingServer.frame_post_draw
		var neutral = root.get_texture().get_image()
		material.set_shader_parameter("inhale_px", 4.0)
		await process_frame
		await RenderingServer.frame_post_draw
		var inhale = root.get_texture().get_image()
		var lower_equal = neutral.get_region(Rect2i(0, 340, 384, 172)).get_data() == inhale.get_region(Rect2i(0, 340, 384, 172)).get_data()
		var upper_changed = neutral.get_region(Rect2i(0, 0, 384, 340)).get_data() != inhale.get_region(Rect2i(0, 0, 384, 340)).get_data()
		print("BREATH_RENDER ", direction, " lower_identical=", lower_equal, " upper_changed=", upper_changed)
		if not lower_equal or not upper_changed: failed += 1
	print("BREATH_RENDER: %s (8 directions, %d failures)" % ["PASS" if failed == 0 else "FAIL", failed])
	quit(0 if failed == 0 else 1)
