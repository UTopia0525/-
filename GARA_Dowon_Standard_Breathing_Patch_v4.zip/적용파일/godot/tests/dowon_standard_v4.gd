extends SceneTree
var checks: int = 0
var failures: int = 0
const INPUTS: Array = [["f_down"], ["f_left", "f_down"], ["f_left"], ["f_left", "f_up"], ["f_up"], ["f_right", "f_up"], ["f_right"], ["f_right", "f_down"]]

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var scene = load("res://prototypes/f_style_trial/dowon_standard_v4/standard_review.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	var actor = scene.actor
	check(actor.direction_frames.size() == 8, "eight directions loaded")
	check(actor.textures.size() == 4, "old atlas retained")
	check(actor.idle_textures.size() == 8, "all eight standard idle sprites loaded")
	check(is_equal_approx(actor.speed, 4.8), "speed preserved")
	check(actor.footprint.size.is_equal_approx(Vector2(0.3, 0.3)), "footprint preserved")
	check(actor.collision_layer == 2 and actor.collision_mask == 1, "collision layers preserved")
	check(scene.camera.zoom.is_equal_approx(Vector2.ONE * 0.85), "camera preserved")
	for direction in range(8):
		check(actor.direction_frames[direction].size() == 8, "eight frames per direction")
		for frame in actor.direction_frames[direction]:
			check(frame.region.position.x >= 0 and frame.region.end.x <= frame.atlas.get_width() and frame.region.position.y >= 0 and frame.region.end.y <= frame.atlas.get_height(), "atlas region in bounds")
		actor.set_logical(Vector2(30, 30))
		actor.distance_walked = 0.0
		var seen: Dictionary = {}
		for action in INPUTS[direction]: Input.action_press(action)
		for tick in range(55):
			await physics_frame
			seen[actor.displayed_frame] = true
		check(actor.direction_index == direction, "input direction maps to correct sheet")
		check(seen.size() == 8, "movement visits all eight frames")
		check(actor.logical.distance_to(Vector2(30, 30)) > 3.0, "logical movement happens")
		check(actor.sprite.texture.atlas.resource_path.ends_with("/walk-%s.png" % scene.art.directions[direction]), "correct art bound to input")
		check(actor.sprite.scale.is_equal_approx(Vector2.ONE * 0.1875), "walking uses standard scale")
		check(actor.sprite.position.is_equal_approx(Vector2(-36, -93.75)), "walking uses standard anchor")
		var previous_position: Vector2 = actor.logical
		var previous_distance: float = actor.distance_walked
		actor.toggle_revision()
		check(actor.sprite.texture == actor.textures[actor.walk_frame][direction], "old art comparison per direction")
		check(actor.logical.is_equal_approx(previous_position) and is_equal_approx(actor.distance_walked, previous_distance), "V preserves position and cycle")
		actor.toggle_revision()
		for action in INPUTS[direction]: Input.action_release(action)
		await physics_frame
		await physics_frame
		var idle_texture: Texture2D = actor.idle_textures[direction]
		check(not actor.moving and actor.sprite.texture == idle_texture, "idle uses correct directional pose")
		check(actor.sprite.scale.is_equal_approx(Vector2.ONE * 0.1875), "idle shares same scale")
		check(actor.sprite.position.is_equal_approx(Vector2(-36, -93.75)), "idle shares same anchor")
	actor.set_logical(Vector2(30, 30))
	var before: Vector2 = actor.logical
	var distance_before: float = actor.distance_walked
	scene.set_review_paused(true)
	Input.action_press("f_down")
	for tick in range(5): await physics_frame
	Input.action_release("f_down")
	check(actor.logical.is_equal_approx(before), "pause stops movement")
	check(is_equal_approx(actor.distance_walked, distance_before), "pause stops phase")
	for direction in range(8):
		actor.direction_index = direction
		actor.manual_frame = -1
		for frame in range(8):
			actor.step_pose()
			check(actor.displayed_frame == frame and actor.direction_index == direction, "manual stepping respects current direction")
	actor.show_reference = true
	actor._pose()
	check(actor.reference_sprite.visible, "standard overlay visible")
	await process_frame
	await process_frame # SceneTree signal precedes node _process; allow UI refresh.
	check(scene.reference_detail.visible, "large comparison overlay visible")
	check(scene.reference_detail.size == scene.detail.size and scene.reference_detail.position == scene.detail.position, "large overlay uses identical canvas")
	check(actor.reference_sprite.scale.is_equal_approx(actor.sprite.scale) and actor.reference_sprite.position.is_equal_approx(actor.sprite.position), "overlay and walk share transform")
	actor.force_idle = true
	actor._pose()
	check(actor.sprite.texture == actor.idle_textures[actor.direction_index], "I forces standard standing at same position")
	check(actor.logical.is_equal_approx(before) and is_equal_approx(actor.distance_walked,distance_before), "standing comparison does not advance time or movement")
	actor.direction_index = 0
	actor.turn_review(-1)
	check(actor.direction_index == 7, "manual direction wraps backward")
	actor.turn_review(1)
	check(actor.direction_index == 0, "manual direction wraps forward")
	check(actor.logical.is_equal_approx(before), "manual inspection never moves character")
	actor.toggle_cycle()
	check(is_equal_approx(actor.review_cycle_distance, 3.84) and is_equal_approx(actor.speed, 4.8), "cycle option preserves speed")
	actor.toggle_cycle()
	scene.set_review_paused(false)
	check(actor.manual_frame == -1 and actor.is_physics_processing(), "resume clears manual pose")
	actor.set_logical(Vector2(7.7, 9.0))
	Input.action_press("f_left")
	Input.action_press("f_up")
	for tick in range(30): await physics_frame
	Input.action_release("f_left")
	Input.action_release("f_up")
	check(actor.logical.x > 7.12, "building collision preserved")
	if "--capture" in OS.get_cmdline_user_args():
		for direction in [0, 1, 5, 6]:
			scene.set_review_paused(false)
			actor.set_logical(Vector2(8.5, 11))
			for action in INPUTS[direction]: Input.action_press(action)
			for tick in range(8): await physics_frame
			for action in INPUTS[direction]: Input.action_release(action)
			scene.set_review_paused(true)
			await process_frame
			await RenderingServer.frame_post_draw
			var path: String = OS.get_environment("DOWON_WALK8_CAPTURE_DIR").path_join("%s.png" % scene.art.directions[direction])
			check(root.get_texture().get_image().save_png(path) == OK, "render capture saved")
			if direction in [5, 6]:
				scene.set_review_paused(false)
				await physics_frame
				await physics_frame
				scene.set_review_paused(true)
				await process_frame
				await RenderingServer.frame_post_draw
				path = OS.get_environment("DOWON_WALK8_CAPTURE_DIR").path_join("%s-idle.png" % scene.art.directions[direction])
				check(root.get_texture().get_image().save_png(path) == OK, "corrected idle capture saved")
		for direction in [3, 4]:
			actor.direction_index = direction
			actor.moving = false
			actor.manual_frame = -1
			actor._pose()
			await process_frame
			await RenderingServer.frame_post_draw
			var path: String = OS.get_environment("DOWON_WALK8_CAPTURE_DIR").path_join("%s-idle.png" % scene.art.directions[direction])
			check(root.get_texture().get_image().save_png(path) == OK, "back idle capture saved")
	# Idle breathing is visual-only; every direction uses the same cycle.
	scene.set_review_paused(true)
	actor.moving = false
	actor.manual_frame = -1
	actor.force_idle = false
	actor.use_revision = true
	actor.breathing_paused = false
	actor.set_process(false)
	for direction in range(8):
		actor.direction_index = direction
		actor.breathing_elapsed = 0.0
		actor._pose()
		var ground_before: Vector2 = actor.position
		var logical_before: Vector2 = actor.logical
		var footprint_before: Rect2 = actor.footprint
		var phase_before: float = actor.distance_walked
		check(actor.sprite.material == actor.breathing_material, "idle shader active in all directions")
		actor.advance_breathing(actor.breathing_period * 0.5)
		check(is_equal_approx(float(actor.breathing_material.get_shader_parameter("inhale_px")), 4.0), "half-cycle reaches small inhale maximum")
		check(actor.position == ground_before and actor.logical == logical_before and actor.footprint == footprint_before, "breathing never moves foot/collision/logical position")
		check(actor.sprite.scale == Vector2.ONE * 0.1875 and actor.sprite.position == Vector2(-36, -93.75), "breathing never scales or translates entire sprite")
		check(is_equal_approx(actor.distance_walked, phase_before), "breathing does not advance walking phase")
		actor.advance_breathing(actor.breathing_period * 0.5)
		check(is_zero_approx(float(actor.breathing_material.get_shader_parameter("inhale_px"))), "full cycle returns continuously to neutral")
	actor.advance_breathing(0.9)
	actor.breathing_paused = true
	var stopped_phase: float = actor.breathing_elapsed
	actor.advance_breathing(1.0)
	check(is_equal_approx(actor.breathing_elapsed, stopped_phase), "review pause freezes breathing")
	actor.breathing_paused = false
	actor.moving = true
	actor._pose()
	check(actor.sprite.material == null and is_zero_approx(actor.breathing_elapsed), "walking has no shader/color/deformation and resets breathing")
	actor.moving = false
	actor._pose()
	check(is_zero_approx(float(actor.breathing_material.get_shader_parameter("inhale_px"))), "idle entry starts neutral without jump")
	actor.breathing_enabled = false
	actor._sync_breathing()
	check(actor.sprite.material == null, "breathing can be disabled for visual comparison")
	actor.breathing_enabled = true
	actor._sync_breathing()
	actor.set_logical(Vector2(8.5, 11))
	check(is_zero_approx(actor.breathing_elapsed), "restart resets breathing")
	actor.manual_frame = 3
	actor._pose()
	check(actor.sprite.material == null, "manual walk inspection never breathes")
	actor.force_idle = true
	actor._pose()
	check(actor.sprite.material == actor.breathing_material, "forced idle uses idle breathing material")
	await process_frame
	await process_frame
	check(scene.detail.material == actor.sprite.material, "enlarged idle view shares exact breathing state")
	scene.queue_free()
	await process_frame
	check(not InputMap.has_action("f_down"), "scene input cleanup")
	print("DOWON_V4_REVIEW: %s (%d checks, %d failures)" % ["PASS" if failures == 0 else "FAIL", checks, failures])
	quit(0 if failures == 0 else 1)
