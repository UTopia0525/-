extends "res://prototypes/f_style_trial/dowon_actor.gd"
var use_revision: bool = true
var review_cycle_distance: float = 1.9
var manual_frame: int = -1
var force_idle: bool = false
var direction_frames: Array = []
var idle_textures: Array[Texture2D] = []
var displayed_frame: int = 0
var standard: Dictionary
var reference_sprite: Sprite2D
var show_reference: bool = false

func setup(art: Dictionary) -> void:
	standard = JSON.parse_string(FileAccess.get_file_as_string("res://prototypes/f_style_trial/dowon_walk_fix_v5/standard.json"))
	var width: int = standard.cell_size[0]
	var height: int = standard.cell_size[1]
	for direction in standard.directions:
		var sheet: Texture2D = load("res://prototypes/f_style_trial/dowon_walk_fix_v5/walk-%s.png" % direction)
		assert(sheet.get_size() == Vector2(width * 4, height * 2))
		var frames: Array[AtlasTexture] = []
		for index in range(8):
			var texture := AtlasTexture.new()
			texture.atlas = sheet
			texture.region = Rect2((index % 4) * width, (index / 4) * height, width, height)
			frames.append(texture)
		direction_frames.append(frames)
		var idle: Texture2D = load("res://prototypes/f_style_trial/dowon_walk_fix_v5/idle-%s.png" % direction)
		assert(idle.get_size() == Vector2(width, height))
		idle_textures.append(idle)
	super.setup(art)
	reference_sprite = Sprite2D.new()
	reference_sprite.centered = false
	reference_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	reference_sprite.modulate = Color(0.2, 0.8, 1.0, 0.32)
	reference_sprite.z_index = 1
	add_child(reference_sprite)
	_pose()

func _pose() -> void:
	if not is_instance_valid(sprite): return
	var phase: float = fposmod(distance_walked / review_cycle_distance, 1.0)
	if manual_frame >= 0: phase = manual_frame / 8.0
	if not use_revision:
		walk_frame = mini(3, floori(phase * 4.0)) if moving or manual_frame >= 0 else 0
		displayed_frame = walk_frame
		super._pose()
	else:
		# Exactly one scale/anchor for every idle and walking direction/frame.
		sprite.scale = Vector2.ONE * float(standard.display_scale)
		sprite.position = -Vector2(standard.anchor[0], standard.anchor[1]) * sprite.scale
		if force_idle or (not moving and manual_frame < 0):
			displayed_frame = 0
			sprite.texture = idle_textures[direction_index]
		else:
			displayed_frame = mini(7, floori(phase * 8.0))
			sprite.texture = direction_frames[direction_index][displayed_frame]
	_update_reference()

func _update_reference() -> void:
	if not is_instance_valid(reference_sprite): return
	reference_sprite.texture = idle_textures[direction_index]
	reference_sprite.scale = Vector2.ONE * float(standard.display_scale)
	reference_sprite.position = -Vector2(standard.anchor[0], standard.anchor[1]) * reference_sprite.scale
	reference_sprite.visible = show_reference

func toggle_revision() -> void:
	use_revision = not use_revision
	_pose()

func toggle_cycle() -> void:
	review_cycle_distance = 3.84 if is_equal_approx(review_cycle_distance, 1.9) else 1.9
	_pose()

func step_pose() -> void:
	force_idle = false
	manual_frame = (manual_frame + 1) % 8
	_pose()

func turn_review(step: int) -> void:
	direction_index = posmod(direction_index + step, 8)
	if manual_frame < 0: manual_frame = 0
	_pose()

func resume_pose() -> void:
	manual_frame = -1
	force_idle = false
	_pose()
